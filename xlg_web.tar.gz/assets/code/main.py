import pygame, sys, asyncio
from settings import *
from level import Level

class Game:
	def __init__(self):
		pygame.init()
		self.screen = pygame.display.set_mode((SCREEN_WIDTH,SCREEN_HEIGHT))
		pygame.display.set_caption('萌芽之地')
		self.clock = pygame.time.Clock()
		self.level = Level()

		# ---- 操作说明画面 ----
		self.show_instructions = True
		self.instruction_bg = pygame.image.load('../graphics/czsm.png').convert_alpha()
		self.instruction_font = pygame.font.Font('../font/HYPixel11pxU-2.ttf', 22)

		# 预渲染说明文字
		instruction_lines = [
			'控制角色移动：方向键(上下左右) / 手机左下角十字键',
			'空格键 / [工具]键：使用当前装备的工具',
			'Q键 / [切工具]键：切换工具（锄头→斧头→水壶）',
			'左Ctrl键 / [播种]键：在耕地上播种当前选中的种子',
			'E键 / [切种子]键：切换种子类型（玉米/番茄）',
			'回车键 / [互动]键：与面前的物体互动（商店/睡觉）',
		]
		self.instruction_text_surfs = [
			self.instruction_font.render(line, False, 'White')
			for line in instruction_lines
		]
		self.instruction_hint = self.instruction_font.render('按回车键或点击屏幕下方[互动/继续]按钮...', False, 'White')

	def display_instructions(self, dt):
		# 先渲染游戏画面作为背景
		self.level.run(dt)

		# 半透明暗色遮罩
		overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
		overlay.fill((0, 0, 0, 180))
		self.screen.blit(overlay, (0, 0))

		# 居中显示操作说明背景图
		img_rect = self.instruction_bg.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2))
		self.screen.blit(self.instruction_bg, img_rect)

		# 在背景图上渲染说明文字
		line_spacing = 45
		text_start_y = img_rect.top + 30

		for i, text_surf in enumerate(self.instruction_text_surfs):
			text_rect = text_surf.get_rect(
				centerx=img_rect.centerx,
				top=text_start_y + i * line_spacing
			)
			self.screen.blit(text_surf, text_rect)

		# 底部关闭提示
		hint_rect = self.instruction_hint.get_rect(
			centerx=img_rect.centerx,
			bottom=img_rect.bottom - 50
		)
		self.screen.blit(self.instruction_hint, hint_rect)

	async def run(self):
		while True:
			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					pygame.quit()
					sys.exit()
				# 操作说明画面中按回车键关闭，或鼠标/触屏点击关闭
				if self.show_instructions:
					if event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
						self.show_instructions = False
					elif event.type == pygame.MOUSEBUTTONDOWN:
						self.show_instructions = False

			dt = min(self.clock.tick() / 1000, 0.1)
			if self.show_instructions:
				self.display_instructions(dt)
			else:
				self.level.run(dt)
			pygame.display.update()
			await asyncio.sleep(0)

if __name__ == '__main__':
	game = Game()
	asyncio.run(game.run())
