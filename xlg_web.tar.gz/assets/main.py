import asyncio
import os
import sys

# Ensure current working directory is the 'code' directory
# so that all relative asset references (../graphics, ../audio, ../data, ../font) resolve properly.
base_dir = os.path.dirname(os.path.abspath(__file__))
code_dir = os.path.join(base_dir, 'code')
if os.path.isdir(code_dir):
    if code_dir not in sys.path:
        sys.path.insert(0, code_dir)
    os.chdir(code_dir)

import pygame
from main import Game

async def main():
    game = Game()
    await game.run()

if __name__ == '__main__':
    asyncio.run(main())
